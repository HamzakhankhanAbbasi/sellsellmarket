

<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/jquery-3.5.1.min.js"></script>
<script src="assets/js/stellarnav.min.js"></script>
<script src="assets/js/swiper-bundle.min.js"></script>
<script src="assets/js/jquery.fancybox.min.js"></script> 
<script src="assets/js/aos.js"></script>
<script src="assets/js/custom.js"></script> 
<script>
	AOS.init();
</script>



</body>
</html>